
public class Main {
public static void main(String[] args) {
	Ficha ficha =new Ficha(1,new Casillero("Tierra",0,new Posicion(0,0)),
			new Casillero("Tierra",1,new Posicion(0,1)));
	System.out.println(ficha);
	
}
}
