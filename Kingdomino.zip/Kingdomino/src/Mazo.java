import java.util.ArrayList;

public class Mazo {
	int indice; // Para saber a partir de que carta sacar fichas
	int cantFichas;
	ArrayList<Ficha> listaDeFichas = new ArrayList<Ficha>();

	Mazo() {
		for (int i = 0; i < 48; i++) {
			// Harcodear las 48 fichas
//			Ficha ficha =new Ficha(i,new Casillero("Tierra",0,new Posicion(0,0)),
//					new Casillero("Tierra",1,new Posicion(0,1)));

		}
		indice = 0;
		cantFichas = 48;// Para que usabamos este dato?
	}
	public void MezclarMazo(){// es necesario? no podemos ir sacando fichas cuando las pedimos usando Math.rand?
		
	}
	public Ficha[] devolverFichas() {
		Ficha fichas[];
		for(int i=0;i<4;i++) {
			
		}
	
		return fichas;
		
	}
	

}
