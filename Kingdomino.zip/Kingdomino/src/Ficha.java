import java.util.Arrays;

public class Ficha {
	int numero;
	Casillero[] subFicha= new Casillero [2];
	
	Ficha() {
		
	}
	 Ficha(int numero, Casillero subFicha1, Casillero subFicha2) {
		this.numero = numero;
		this.subFicha[0] = subFicha1;
		this.subFicha[1] = subFicha2;
	}

	@Override
	public String toString() {
		return "Ficha: " + numero +
	("\n---------------------------------")+
	("\n|" + subFicha[0].getCantDeCoronas()+"		|" + subFicha[1].getCantDeCoronas() +"		|")+
	("\n|" + subFicha[0].getTipoDeTerreno()+"		|" + subFicha[0].getTipoDeTerreno() +"		|")+
	("\n|" + subFicha[0].getPos()+"	|"+ subFicha[1].getPos() +"	|")+
	("\n---------------------------------");
	}
	
	
}
